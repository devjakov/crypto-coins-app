import styled from "styled-components";

export const Form = styled.form`
  margin: auto 0;
  flex: 1;
  position: relative;
`

