import styled from "styled-components";

export const Li = styled.li`
    margin: auto 0;
`