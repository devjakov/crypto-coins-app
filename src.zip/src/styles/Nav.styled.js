import styled from 'styled-components'

export const Nav = styled.nav`
    background-color: #191B1F;
  height: 90px;
`