import styled from "styled-components";

export const RadioWrapper = styled.div`
display: flex;
gap: 2rem;
margin: auto;
padding-top: 2rem;
justify-content: center;

`