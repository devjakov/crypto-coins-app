import styled from "styled-components";

export const CoinDetailsContainer = styled.div`

`