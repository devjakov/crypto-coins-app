import styled from "styled-components";

export const YourSummary = styled.div`
display: flex;
flex-direction: row;
justify-content: space-between;
height: 370px;
width: 100%;
position: relative;
`