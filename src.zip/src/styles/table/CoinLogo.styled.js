import styled from "styled-components";

export const CoinLogo = styled.img`
justify-content: center;
`