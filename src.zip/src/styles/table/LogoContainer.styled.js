import styled from "styled-components";

export const LogoContainer = styled.div`
    
    height: 45%;
    display: inline-flex;
    padding: 0 5%;
`