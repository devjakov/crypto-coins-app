import styled from 'styled-components'

export const Th = styled.th`
background-color: #191B1F;
color: white;
text-align:left;
font-weight: 700;
`