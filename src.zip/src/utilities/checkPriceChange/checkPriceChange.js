
export const checkPriceChange = (price) => {
    return change >= 0 ? faCaretUp : faCaretDown
}