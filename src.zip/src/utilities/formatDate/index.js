const formatDate = (date) =>
    new Date(date).toUTCString();

export default formatDate